# Vinheria Agnello

## Descrição
Este é um projeto de site para a o CP2 da Vinheria Agnello, utilizando HTML e CSS, com animations, transform e transition.

## Funcionalidades
- Carrossel de imagens para destaque de vinhos
- Seção de vinhos em promoção
- Listagem de tipos de vinhos disponíveis

## Tecnologias Utilizadas
- HTML
- CSS

## Como Usar
1. Clone o repositório ou faça o download dos arquivos.
2. Abra o arquivo `index.html` em um navegador web.

## Alunos
Arthur Gomes - RM: 560771
Lucas Villar - RM: 560005
Luiz Gustavo Araújo de Lima - RM: 560110
Matheus Siroma Carmona- RM560248
Pedro Estevam Coelho - RM: 560642